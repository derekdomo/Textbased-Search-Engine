package DataStructure; /**
 *  This class implements the document score list data structure
 *  and provides methods for accessing and manipulating them.
 *
 *  Copyright (c) 2014, Carnegie Mellon University.  All Rights Reserved.
 */

import Main.*;

import java.io.IOException;
import java.util.*;

public class ScoreList {

  //  A little utilty class to create a <docid, score> object.

  protected class ScoreListEntry {
    private int docid;
    private double score;

    private ScoreListEntry(int docid, double score) {
      this.docid = docid;
      this.score = score;
    }
  }

  public List<ScoreListEntry> scores = new ArrayList<ScoreListEntry>();

  /**
   *  Append a document score to a score list.
   *  @param docid An internal document id.
   *  @param score The document's score.
   *  @return void
   */
  public void add(int docid, double score) {
    scores.add(new ScoreListEntry(docid, score));
  }

  /**
   *  Get the n'th document id.
   *  @param n The index of the requested document.
   *  @return The internal document id.
   */
  public int getDocid(int n) {
    return this.scores.get(n).docid;
  }

  /**
   *  Get the score of the n'th document.
   *  @param n The index of the requested document score.
   *  @return The document's score.
   */
  public double getDocidScore(int n) {
    return this.scores.get(n).score;
  }
  /**
   * check whether the docid is in the scores
   * @param docID
   * @return true or false
   * */
  public boolean existDoc(int docID) {
      for (int i=0; i<scores.size(); i++) {
          if (docID==scores.get(i).docid) {
              return true;
          }
      }
      return false;
  }
    /**
     * get the score by docID
     * @param docID
     * @return The document's score
     * */
    public double getDocScoreByID(int docID) {
        for (int i=0; i<scores.size(); i++) {
            if (docID==scores.get(i).docid) {
                return scores.get(i).score;
            }
        }
        return -1;
    }
    /**
     * update the score by the ID
     * @param docID
     * @param score
     * @return true or false
     * */
    public boolean updateDocScore(int docID, double score) {
        for (int i=0; i<scores.size(); i++) {
            if (docID==scores.get(i).docid) {
                scores.get(i).score=score;
                return true;
            }
        }
        return false;
    }
    /**
     * update the score by the ID in Or RB
     * @param docID
     * @param score
     * @return true or false
     * */
    public boolean updateDocScoreRBOr(int docID, double score) {
        for (int i=0; i<scores.size(); i++) {
            if (docID==scores.get(i).docid) {
                if (score>scores.get(i).score)
                    scores.get(i).score=score;
                return true;
            }
        }
        return false;
    }
    /**
     * sort the score list by score
     * */
    public void sort() throws IOException{
        for (int i=0; i<scores.size(); i++) {
            for (int j=i+1; j<scores.size(); j++) {
                double si=scores.get(i).score;
                double sj=scores.get(j).score;
                if (si<sj) {
                    int ssi=scores.get(i).docid;
                    int ssj=scores.get(j).docid;
                    scores.get(i).docid=ssj;
                    scores.get(j).docid=ssi;
                    scores.get(i).score=sj;
                    scores.get(j).score=si;
                }else if (si==sj) {
                    int ssi=scores.get(i).docid;
                    int ssj=scores.get(j).docid;
                    if (MainEval.compareExternalDocid(i, j)>0) {
                        scores.get(i).docid=ssj;
                        scores.get(j).docid=ssi;
                        scores.get(i).score=sj;
                        scores.get(j).score=si;
                    }
                }
            }
        }
    }
  }
