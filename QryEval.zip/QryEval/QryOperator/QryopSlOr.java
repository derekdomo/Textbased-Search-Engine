package QryOperator;

import DataStructure.*;
import RetrievalModel.*;

import java.io.IOException;
import java.util.Iterator;

/**
 * Created by XiangyuSun on 14-9-6.
 */
public class QryopSlOr extends QryopSl {

    public QryopSlOr(Qryop... q) {
        for (int i = 0; i < q.length; i++)
            this.args.add(q[i]);
    }

    /**
     *  Appends an argument to the list of query operator arguments.  This
     *  simplifies the design of some query parsing architectures.
     *  @param {q} q The query argument (query operator) to append.
     *  @return void
     *  @throws IOException
     */
    public void add (Qryop a) {
        this.args.add(a);
    }

    /**
     *  Evaluates the query operator, including any child operators and
     *  returns the result.
     *  @param r A retrieval model that controls how the operator behaves.
     *  @return The result of evaluating the query.
     *  @throws IOException
     */
    public QryResult evaluate(RetrievalModel r) throws IOException {

        if (r instanceof RetrievalModelUnrankedBoolean||r instanceof RetrievalModelRankedBoolean)
            return (evaluateBoolean (r));
        return null;
    }

    /**
     *  Evaluates the query operator for boolean retrieval models,
     *  including any child operators and returns the result.
     *  @param r A retrieval model that controls how the operator behaves.
     *  @return The result of evaluating the query.
     *  @throws IOException
     */
    public QryResult evaluateBoolean (RetrievalModel r) throws IOException {

        //  Initialization

        allocDaaTPtrs (r);
        QryResult result = new QryResult ();
        //add term's scoreList into the result List and check whether it has been added already
        for (int i=0; i<this.daatPtrs.size(); i++) {
            for (int j=0; j<this.daatPtrs.get(i).scoreList.scores.size(); j++) {
                //check whether it is in the result
                int docID = this.daatPtrs.get(i).scoreList.getDocid(j);
                double docScore = this.daatPtrs.get(i).scoreList.getDocidScore(j);
                if (r instanceof RetrievalModelRankedBoolean) {
                    if (!result.docScores.updateDocScoreRBOr(docID, docScore))
                        result.docScores.add(docID, docScore);
                } else{
                    if (!result.docScores.existDoc(docID))
                        result.docScores.add(docID, docScore);
                }
            }
        }
        freeDaaTPtrs ();

        return result;
    }

    /*
     *  Return a string version of this query operator.
     *  @return The string version of this query operator.
     */
    public String toString(){

        String result = new String ();

        for (Iterator<Qryop> i = this.args.iterator(); i.hasNext(); )
            result += (i.next().toString() + " ");

        return ("#or( " + result + ")");
    }

    /*
 *  Calculate the default score for the specified document if it
 *  does not match the query operator.  This score is 0 for many
 *  retrieval models, but not all retrieval models.
 *  @param r A retrieval model that controls how the operator behaves.
 *  @param docid The internal id of the document that needs a default score.
 *  @return The default score.
 */
    public double getDefaultScore (RetrievalModel r, long docid) throws IOException {

        if (r instanceof RetrievalModelUnrankedBoolean)
            return (0.0);

        return 0.0;
    }

}
