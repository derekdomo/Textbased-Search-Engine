/**
 * Created by XiangyuSun on 14-9-8.
 */
import Main.*;
public class QryEval {
    public static void main(String[] args) throws Exception{
        MainEval en = new MainEval();
        en.Entr(args);
    }
}
